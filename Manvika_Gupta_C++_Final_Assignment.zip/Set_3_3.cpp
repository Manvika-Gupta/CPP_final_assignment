#include <iostream>
#include <string>


using namespace std;


int occur=0;


void swap(char &a,char &b){
	char temp;
	temp=a;
	a=b;
	b=temp;
	}	
void check_possibility(string s, int len){
	string temp;	
	for(int i=0;i<len;i++)
	{
	//creating a 2nd char sub string
	temp = s.substr(i,2);
	
	//checking for '01' occurrence
	if(temp=="01")
	{
	occur++;
	}
	}
}


int main()
{
	string str;
	int count = 0;
	cout<<"Enter your string: ";
	cin >> str;
	int len = str.size();
	check_possibility(str,len);

	// check if "01" substring in original string
	count =count+occur;
	cout << "\nPresence of 01 in the original substring " <<str<<" is :"<< occur << endl<<"Now, swapping the even and odd parity bits...\n\n";

	occur=0;
	cout<<"Possible Strings obtained after swapping:\n\n";
	for(int i=0;i<len-2;i++)
	{
	for(int j=i+2;j<len;j+=2){
	string temp = str; //copying the original string to temporary string
	swap(temp[i],temp[j]);

	if(temp!=str){
	check_possibility(temp,len);
	
	cout<<temp<<":"<<endl;
	cout<<" occurrence of 01 is: "<<occur<<endl;
	count = count+occur;
	occur = 0;
	}
	}


	}

cout << "\nTotal occurrence of 01 is : " << count << endl;


return 0;
}
