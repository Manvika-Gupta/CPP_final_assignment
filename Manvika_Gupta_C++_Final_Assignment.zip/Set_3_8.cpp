
#include <iostream>
#include <string>

using namespace std;


void check(string str)
{
    int y= str.size();
    int flag=0;
    //	cout<<y<<endl; //length of string
    string temp;
    for(int i=0;i<y;i++)
    {
        if(i==y-1)
	{
           break;
	}
    temp=str.substr(i,2); //abab //USING SUBSTR FUNCTION!
   
    //cout<<temp<<endl;
    if(temp=="AB" || temp== "BA")
    {
        flag=1;
    }
    else
    {
        flag=0;
   
    break;
    }
    }
    if(flag==1)
    {
        cout<<"YES!"<<endl;
    }
    else
    cout<<"NO!"<<endl;
}

int main()
{
	
    string str1;
    cout<<"Enter your string:\n";
    cin>>str1;
    check(str1);

    return 0;
}

	
	
	

