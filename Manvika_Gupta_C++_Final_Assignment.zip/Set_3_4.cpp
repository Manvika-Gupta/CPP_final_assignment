#include<string.h>
#include <iostream>

using namespace std;
int j=0,r=0;
int arrstore[]={};
string a[]={};

void getlow(int a[] , int N){
   int min = a[0];
   for(int i = 1; i < N; i++){
      if(min > a[i])
         min = a[i];
   }
   cout<<"\nThe smallest LCS is: "<<min<<endl;
}

bool swaper_func(string str, int start, int curr){

 for (int i = start; i < curr; i++)
	 if (str[i] == str[curr])
	 return 0;
 return 1;
}

void FindPermutations(string str, int in, int n){

 if (in >= n) {
	
 cout<<"-->"<<str<<"\n";
 a[j]=str;
 j++;
 return;
 }
 
for (int i = in; i < n; i++) {
 	bool check = swaper_func(str, in, i);
	 if (check) {
 	swap(str[in], str[i]);
 	FindPermutations(str, in + 1, n);
 	swap(str[in], str[i]);
 	}	
 }
}

int LCSubStr(string X, string Y, int m, int n)
{


int LCSuff[m + 1][n + 1];
int result = 0; // Storing length of the LCS

for (int i = 0; i <= m; i++)
{
	for (int j = 0; j <= n; j++)
	{
		if (i == 0 || j == 0)
		LCSuff[i][j] = 0;

		else if (X[i - 1] == Y[j - 1]) {
		LCSuff[i][j] = LCSuff[i - 1][j - 1] + 1;
		result = max(result, LCSuff[i][j]);
		}
		else
		LCSuff[i][j] = 0;
	}
}
	arrstore[r]=result;
	r++;

return result;
}

int main()
{
 
 	int n,k,i,l,m;
 	string str;
	cout << "\nEnter your string : ";
 	cin >> str;
 
  n= str.length();
 cout<<"Following are the substrings of the string "<<str<<endl;
 FindPermutations(str, 0, n);
  for(i=0;i<j;i++){
     cout<<a[i];
 }
 if(j==2){
 	cout<<"\nThe answer is 0";
 }
 else{
	cout << "\n\nThe length of the all the LCS obtained is: \n" ;
 for(i=0;i<j;i++)
 {
     for(k=i+1;k<j;k++){
 	cout<<LCSubStr(a[i], a[k], n, n);
	cout<<"\t";
     }
 }
 }
getlow(arrstore, r);

 return 0;
}
